package com.ridenest.util;

public class ConnectionData {

    public static final String DATABASE = "ridenest_db";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "123456";
}
